
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs, os, sys


from resources.lib.modules.common import *

#from common import *

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.muzic')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
media = 'special://home/addons/script.j1.artwork/lib/resources/images/genres/'
mediapath = 'http://j1wizard.net/media/'

#====================================

channellist=[
        ("[B]Sing King Karaoke Channel[/B]", "user/singkingkaraoke", media+'Karaoke.png'),
        ("[B]Party Tyme Karaoke Channel[/B]", "channel/UCWLqO9ztz16a_Ko4YB9PnFQ", media+'Karaoke.png'),
        ("[B]The Kool Karaoke Channel[/B]", "channel/UC-oncHlt96Hsrct6xBPfyWQ", media+'Karaoke.png'),				
        ("[B]The Elvis Karaoke Channel[/B]", "user/TheMemphischannel", media+'Karaoke.png'),
        ("[B]Bitter Sweet Karaoke Channel[/B]", "channel/UCd2ZDrtepDtDVuU5okVADDw", media+'Karaoke.png'),				
        ("[B]The Easy Karaoke Channel[/B]", "channel/UC-tDkOgdiO7FPav2sF5nkUg", media+'Karaoke.png'),
        ("[B]Stingray Karaoke Channel[/B]", "user/TheKARAOKEChannel", media+'Karaoke.png'),				
        ("[B]The Rock Karaoke Channel[/B]", "channel/UCHMKaDhEKG2SinbnJg4EINw", media+'Karaoke.png'),
        ("[B]Karaoke Junkies Channel[/B]", "channel/UCa98lXtQZFlGrvt6vVn7HAw", media+'Karaoke.png'),
        ("[B]Karaoke On Vevo Channel[/B]", "user/KaraokeOnVEVO", media+'Karaoke.png'),				
        ("[B]BKD Karaoke Studio Channel[/B]", "channel/UCpZa28twjWTnhuTe7b1AYfg", media+'Karaoke.png'),
        ("[B]Good Karaoke Songs Channel[/B]", "channel/UCy8dBiuCv7608bij7iUH_jQ", media+'Karaoke.png'),
        ("[B]The Karaoke Kids Channel[/B]", "channel/UCneJ8C3HBBejoVVD1denUYA", media+'Karaoke.png'),
        ("[B]Christmas Songs N Carols[/B]", "user/childrenlovetosing", media+'Karaoke.png'),
]

#=====================================

class karaokeCH:

    @staticmethod
    def Genres(type):
		
        #errorMsg="%s" % (type)
        #xbmcgui.Dialog().ok("type", errorMsg)

        for title, id, thumbnail in sorted(channellist, reverse=False):
	        Add_Dir(name=title,url="plugin://plugin.video.youtube/"+id+"/",folder=True,icon=thumbnail,fanart=fanart)

#=====================================
