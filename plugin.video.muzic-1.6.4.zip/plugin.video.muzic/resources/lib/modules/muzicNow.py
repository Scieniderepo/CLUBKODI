"""

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs, os, sys


from resources.lib.modules.common import *

#from common import *

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.muzic')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
media = 'special://home/addons/script.j1.artwork/lib/resources/images/genres/'
mediapath = 'http://j1wizard.net/media/'

channellist=[
        ("[B]Now Thats What I call A Raggae Party[/B]", "rTWtAYiUneE", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call The 80s[/B]", "QVjn237NQaA", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 104[/B]", "R7QK0zNiYcY", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Halloween[/B]", "xUNPpt8AxRc", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call A Summer Party[/B]", "UipaovgEdIQ", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Christmas[/B]", "5MFUwMddZ8g", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call The 80s v2[/B]", "CK1VwmTclB8", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 70[/B]", "iKNC1KOKeT8", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 71[/B]", "kO7oBjBzf9w", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 72[/B]", "UJWOkWdqFnw", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 69[/B]", "MTjemQr2KbE", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now 100 Hits Movies [/B]", "OCkN9szTby8", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 99[/B]", "q0Hz9jcgr5k", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 97[/B]", "QiUwNhHUs2s", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 46[/B]", "LB2HpjQVUzo", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 103[/B]", "ZBWEhmaef2I", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 68[/B]", "Quil1YKwFL4", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 101[/B]", "ZglypxFJEkw", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 102[/B]", "9qqI96UxPOk", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 98[/B]", "rZweig6CAx8", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 95[/B]", "sVEs6Kdm_5c", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Disney II[/B]", "kFLyxwSX91I", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Disney III[/B]", "BAGshtobidI", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Party Anthems 3[/B]", "i0NZlQsY0Hg", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Disney I[/B]", "ZiiwOtsreyM", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I call Music 67[/B]", "Quil1YKwFL4", 801, "Mix", mediapath+'muzic_music.png', fanart),
        ("[B]Now Thats What I Call Rock&Roll[/B]", "Feh3vWX-jFE", 801, "Mix", mediapath+'muzic_music.png', fanart),
]

#=====================================

class nowListing:

    @staticmethod
    def Genres(type):
		
        #errorMsg="%s" % (type)
        #xbmcgui.Dialog().ok("type", errorMsg)

        for name, url, zmode, genre, icon, fanart in sorted(channellist, reverse=False):
	        addLink(name,url,zmode,icon,fanart)

#=====================================

