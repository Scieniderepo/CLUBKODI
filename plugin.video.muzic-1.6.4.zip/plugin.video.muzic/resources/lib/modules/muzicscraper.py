"""

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import os, re, sys, string, json, random, base64
import shutil
import urllib
import time
#import urllib2

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

convert_special_characters = HTMLParser()
dlg = xbmcgui.Dialog()

from resources.lib.modules.common import *

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

art = 'special://home/addons/plugin.video.docula/resources/media/'
mediapath = 'special://home/addons/script.j1.artwork/lib/resources/images/genres/'

#==========================================================================================================

class Listing:

    @staticmethod
    def Genres(type,list):

        #errorMsg="%s" % (type)
        #xbmcgui.Dialog().ok("type", errorMsg)

        #errorMsg="%s" % (list)
        #xbmcgui.Dialog().ok("list", errorMsg)

        if list is "Concerts": eventsUrl = 'http://j1wizard.net/config/texts/muzicconcerts.txt'
        if list is "Docs": eventsUrl = 'http://j1wizard.net/config/texts/muzicdocs.txt'
        if list is "Genres": eventsUrl = 'http://j1wizard.net/config/texts/muzicgenres.txt'

        try: #Python 2
            link = OPEN_URL(eventsUrl).replace('\n','').replace('\r','').replace('\t','')
            #match = re.compile('item="(.+?)", "(.+?)", 801, "(.+?)", "(.+?)", fanart').findall(link)
        except: #Python 3
            link = OPEN_URL(eventsUrl)
            link = link.decode('ISO-8859-1')  # encoding may vary!

        match = re.compile('item="(.+?)", "(.+?)", 801, "(.+?)", "(.+?)", fanart').findall(link)
		
        #errorMsg="%s" % (match)
        #xbmcgui.Dialog().ok("match", errorMsg)

        for name, url, genre, image in match:

            addIt=False
            if type is "All":
                icon=mediapath+"All-muzic.png"
                addIt=True

            elif type is "Alternative" and "Alternative" in genre:
                icon=mediapath+"Alternative.png"
                addIt=True

            elif type is "Anthem" and "Anthem" in genre:
                icon=mediapath+"Anthem.png"
                addIt=True

            elif type is "Blues" and "Blues" in genre:
                icon=mediapath+"Blues.png"
                addIt=True

            elif type is "Country" and "Country" in genre:
                icon=mediapath+"Country.png"
                addIt=True

            elif type is "Docs" and "Docs" in genre:
                icon=mediapath+"Docs.png"
                addIt=True

            elif type is "HipHop" and "HipHop" in genre:
                icon=mediapath+"Hip Hop.png"
                addIt=True

            elif type is "Jazz" and "Jazz" in genre:
                icon=mediapath+"Jazz.png"
                addIt=True

            elif type is "Metal" and "Metal" in genre:
                icon=mediapath+"Metal.png"
                addIt=True

            elif type is "Movie" and "Movie" in genre:
                icon=mediapath+"Movie.png"
                addIt=True

            elif type is "Pop" and "Pop" in genre:
                icon=mediapath+"Pop.png"
                addIt=True

            elif type is "Punk" and "Punk" in genre:
                icon=mediapath+"Punk.png"
                addIt=True

            elif type is "RnB" and "RnB" in genre:
                icon=mediapath+"RnB.png"
                addIt=True

            elif type is "Rock" and "Rock" in genre:
                icon=mediapath+"Rock.png"
                addIt=True

            elif type is "Rap" and "Rap" in genre:
                icon=mediapath+"Rap.png"
                addIt=True

            elif type is "Soul" and "Soul" in genre:
                icon=mediapath+"Soul.png"
                addIt=True

            elif type is "TV" and "TV" in genre:
                icon=mediapath+"TV.png"
                addIt=True
		
            if addIt==True:
                addLink(name,url,801,icon,fanart)

#=====================================
   
def OPEN_URL(url):

    try: #Python 2
        req = Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urlopen(req)
        link=response.read()
        response.close()
        return link
    except: #Python 3
        req = urllib.request.Request(url)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib.request.urlopen(req)
        link=response.read()
        response.close()
        return link
	
#=====================================

def urlExists(url):

    request = Request(url)
    request.get_method = lambda: 'HEAD'

    try:
        urlopen(request)
        return True
    except HTTPError:
        return False
	
#=====================================
