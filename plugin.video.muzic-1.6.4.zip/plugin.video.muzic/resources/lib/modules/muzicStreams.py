"""

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs, os, sys

from resources.lib.modules.common import *

#from common import *

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.muzic')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

channellist=[
        ("[B]Progressive House[/B]", "d8Oc90QevaI", 801, "Mix", mediapath+'muzic_streams.png', fanart),
        ("[B]Doom Metal Music[/B]", "dGfdGZ8cH-o", 801, "Metal", mediapath+'muzic_streams.png', fanart),
        ("[B]Lofi Hip Hop Mix[/B]", "2atQnvunGCo", 801, "HipHop", mediapath+'muzic_streams.png', fanart),
        ("[B]Vocal Trance[/B]", "C6_ql03n-vQ", 801, "Trance", mediapath+'muzic_streams.png', fanart),
        ("[B]Jazz Hip Hop[/B]", "g-pqmuYPHPs", 801, "Jazz, HipHop", mediapath+'muzic_streams.png', fanart),
        ("[B]Rap Radio Music[/B]", "05689ErDUdM", 801, "Rap", mediapath+'muzic_streams.png', fanart),
        ("[B]Space Ambient Music[/B]", "tNkZsRW7h2c", 801, "Alternative", mediapath+'muzic_streams.png', fanart),
        ("[B]Deep House Relax[/B]", "5qky3L2Q6G4", 801, "Mix", mediapath+'muzic_streams.png', fanart),
        ("[B]Chill Out Lounge Jazz[/B]", "fEvM-OUbaKs", 801, "Jazz", mediapath+'muzic_streams.png', fanart),
        ("[B]Chill Music[/B]", "gmv54pfxk0Q", 801, "Sleep", mediapath+'muzic_streams.png', fanart),
        ("[B]Progressive House Focus[/B]", "KvRVky0r7YM", 801, "Mix", mediapath+'muzic_streams.png', fanart),
        ("[B]NCS Electronic[/B]", "oZzQC8NVTeM", 801, "Electro", mediapath+'muzic_streams.png', fanart),
        ("[B]Best Gaming Mix[/B]", "eosLoIMzW7E", 801, "Mix", mediapath+'muzic_streams.png', fanart),
        ("[B]Sad Boys Radio[/B]", "J20u_NrRI-s", 801, "Mix", mediapath+'muzic_streams.png', fanart),
]

#=====================================

class streamListing:

    @staticmethod
    def Genres(type):
		
        #errorMsg="%s" % (type)
        #xbmcgui.Dialog().ok("type", errorMsg)

        for name, url, zmode, genre, icon, fanart in sorted(channellist, reverse=False):
	        addLink(name,url,zmode,icon,fanart)

#=====================================

