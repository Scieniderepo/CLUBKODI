# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

#from resources.lib.modules.channels import *
from resources.lib.modules.common import *

#params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.muzic')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"
pBASE = "plugin://plugin.video.youtube/play/?playlist_id="

YOUTUBE_CHANNEL_ID_1001 = "PLz-ueGJu2ttxuN4JJ9mvQHF6SY01ppTu2" #Rock Concerts
YOUTUBE_CHANNEL_ID_1002 = "" #
YOUTUBE_CHANNEL_ID_1003 = "PLHrguy3J2ka2NrIba_vzXMw6ZCOSeJagd" #Metal - Melodic Rock Concert
YOUTUBE_CHANNEL_ID_1004 = "PL9E2247E7FB170695"                 #Heavy Metal Concerts
YOUTUBE_CHANNEL_ID_1005 = "PLjnLr2jju2XRB5ytT78GkOWFgEHHV2UXu" #Country Music Concerts
YOUTUBE_CHANNEL_ID_1006 = "PLyVBTKAo39520rdzDVLzHhpuQhB8xTYn5" #Hard Rock And Metal Concerts
YOUTUBE_CHANNEL_ID_1007 = "PLn7pXwjAGmSb33dkTLe0IPaOHRWGyGdgo" #720p HD Rock Concerts
YOUTUBE_CHANNEL_ID_1008 = "PL61D5D6C727B75900"                 #Rock Am Ring Concert
YOUTUBE_CHANNEL_ID_1009 = "PLHYMOlHLLJWjAs_o1HfPLK-KyVQelfHG7" #Joe Cocker Concerts
YOUTUBE_CHANNEL_ID_1010 = "PL4h2XGENb6qgvG_a5lTa9OWcJbv-hxr0K" #Moshcam Full Concerts
YOUTUBE_CHANNEL_ID_1011 = "" #
YOUTUBE_CHANNEL_ID_1012 = "PLbH0pgIpVVNJDjBm_QF3W34HsExL4Zjxp" #Concerts: Kiss
YOUTUBE_CHANNEL_ID_1013 = "PLoFjUTMRAKTKuNaxHwc0m9K5_u6F7bCW7" #HD Concert Mix
YOUTUBE_CHANNEL_ID_1014 = "PLojo7U9os41y9ANgVIDzQtnN6bDiNCgCI" #Full Length Artist Concerts
YOUTUBE_CHANNEL_ID_1015 = "PLAF7B3FDCD57F4373"                 #Oldies, Soul RnB, Funk
YOUTUBE_CHANNEL_ID_1016 = "PLtBkrHcCq1fqkKt-9knguy_xbjo9rDyCZ" #Classical Full Length Concerts
YOUTUBE_CHANNEL_ID_1017 = "PL5kCjBbUtVeOGMWdyYqAiAupYKtx0T8mB" #Tokyo Jazz Festival
YOUTUBE_CHANNEL_ID_1018 = "PLBWCFQsZmG3VBgnQoq9X120N8VcnnRH3Y" #Concerts: David Bowie
YOUTUBE_CHANNEL_ID_1019 = "PLFCF55651BB105A0A"                 #Christian Music Concerts
YOUTUBE_CHANNEL_ID_1020 = "PLyVBTKAo3950wwFRrggIXssMf0sdyGjQK" #RnB And Soul Music Concerts
YOUTUBE_CHANNEL_ID_1021 = "PLKnoifHxcT0bPD7UOhIIls1a_MXvxHH0C" #Complete Concerts: Blues
YOUTUBE_CHANNEL_ID_1022 = "PL5WFRyLzmGi40V88ySTRJhQ6lJf0mYuDc" #Eminem Concerts
YOUTUBE_CHANNEL_ID_1023 = "PLdTy4tnpIn-PuUJaziWbheSLwnpdKrPF8" #Mix Genre Concerts
YOUTUBE_CHANNEL_ID_1024 = "PLsDZ7QcsbDR8Wx2-l1oDvJA-77ioQ6mDZ" #David Gilmour At Pompiee
YOUTUBE_CHANNEL_ID_1025 = "" #
YOUTUBE_CHANNEL_ID_1026 = "" #
YOUTUBE_CHANNEL_ID_1027 = "" #
YOUTUBE_CHANNEL_ID_1028 = "" #
YOUTUBE_CHANNEL_ID_1029 = "PL5jPQshWo8ryN8J3iYjQXx6OVERHaPU4G" #1080p Rock Songs
YOUTUBE_CHANNEL_ID_1030 = "PLsFQE5aB1i0kqyiqZL9G-dBicrI7rjg2J" #AC-DC Songs
YOUTUBE_CHANNEL_ID_1031 = "PL8kT4dvTy89Aph9woc2QYR0W9td8XfgQU" #HD Original Music Videos
YOUTUBE_CHANNEL_ID_1032 = "PLC4nJr66Up76gWXJiebwdU9eGUdgkmKH_" #U2 Songs HD
YOUTUBE_CHANNEL_ID_1033 = "PLsDmg8LRtIvCpVeQLUDwMqpGq1FxH5UD-" #Elvis Presley 68 Comeback
YOUTUBE_CHANNEL_ID_1034 = "PLiy_P4zvPntMn0K1dETx5vWSssEjL4_ml" #80s Glam, Rock, Hair Metal
YOUTUBE_CHANNEL_ID_1035 = "PLrJ6b7vTnAPaBoscn3139zw_FICNMqddB" #Songs: Pink Floyd Pulse
YOUTUBE_CHANNEL_ID_1036 = "PLN6VwWFcVaZxqKvYfRiuF8erewXJg0-w4" #Slow Rock, Anthem
YOUTUBE_CHANNEL_ID_1037 = "PLn0TaAb1LMwr5IG5W4n2D-Ze0D5v6uK_x" #Vevo Best Rock 2019
YOUTUBE_CHANNEL_ID_1038 = "PLVXq77mXV53-Np39jM456si2PeTrEm9Mj" #Top Tracks Classical Music
YOUTUBE_CHANNEL_ID_1039 = "PLvcAGla8nnjMhF5_6SeBayVma1LD3xMvG" #Demi Lovato Top 50
YOUTUBE_CHANNEL_ID_1040 = "PLPYC---L3hwlkks6y7CvYEfxEXn3AKg_q" #Country Music Playlist
YOUTUBE_CHANNEL_ID_1041 = "PL68D2C1F5A168B806"                 #Female Folk Singers
YOUTUBE_CHANNEL_ID_1042 = "PLw6p6PA8M2mh4Uw1FMNe9H8ft7EY2XN-1" #Guitar Heroes: The Soloist
YOUTUBE_CHANNEL_ID_1043 = "PLi50Rp1hHewW_mgBBuPqh3FBePWbGqWey" #Oldies Music Mix
YOUTUBE_CHANNEL_ID_1044 = "PLhe-gsNZb0-pYU1Ai7JHpmw7-fdfpb4Aa" #Favorites Music Mix
YOUTUBE_CHANNEL_ID_1045 = "" #
YOUTUBE_CHANNEL_ID_1046 = "" #
YOUTUBE_CHANNEL_ID_1047 = "PLhbybU92e5n_V2InlRSTI4_5qpjbGuppI" #The Who: Songs And Concerts
YOUTUBE_CHANNEL_ID_1048 = "PL3ylOx8mWyAyRCQQQPUR3Zt0zNpdcbPzK" #Midnight Special TV Collection
YOUTUBE_CHANNEL_ID_1049 = "PLEXox2R2RxZKD0KvMoTYSiKnxwOn2joVU" #Greatest New Wave Songs
YOUTUBE_CHANNEL_ID_1050 = "PLzMhF_Kgqw3iZBdZ4sX-kdVaWPCEo3q9B" #Alice Cooper Greatest Hits
YOUTUBE_CHANNEL_ID_1051 = "PLuUrokoVSxlfUJuJB_D8j_wsFR4exaEmy" #Hip Hop Songs 2019
YOUTUBE_CHANNEL_ID_1052 = "PL15B1E77BB5708555"                 #Most Viewed On Youtube
YOUTUBE_CHANNEL_ID_1053 = "PL9RiXq3CWn9rqDe-4vKilPgeFzbStaxr-" #Best Rap Songs 2019
YOUTUBE_CHANNEL_ID_1054 = "PLLDVfSPfze0tOzlLGWe_WUd4VXeO7ATEZ" #Country Top 40 Songs
YOUTUBE_CHANNEL_ID_1055 = "PLuRo0Z9OfQyMBY76Ak-WviDtS4FBcZ37d" #Top 100 Hip Hop Videos
YOUTUBE_CHANNEL_ID_1056 = "PLkqz3S84Tw-RrA5S0qoVYlQ3CmwIljp3j" #Hottest Rap Video Playlist
YOUTUBE_CHANNEL_ID_1057 = "" #
YOUTUBE_CHANNEL_ID_1058 = "PL_7S9gC5sYVOX364JOfD30kuV5SWCzUl8" #Clean RnB And Hip Hop Music
YOUTUBE_CHANNEL_ID_1059 = "PLXBmmdLdhrBqqv62HE4FOgivDxYF_blwl" #Classic Rock Live Performances
YOUTUBE_CHANNEL_ID_1060 = "PLA58kjq4VsdNULUhz-BE_zsy9W4onszwl" #Songs: Jazz Rock Fusion
YOUTUBE_CHANNEL_ID_1061 = "PLMBnX-RGobFTuJJ_1Mf6PHQROExJeIRBP" #New Gaither List 2018
YOUTUBE_CHANNEL_ID_1062 = "PLvPG3YUtlLt-2bVQyAm5pHTYTomRsKRm_" #Greatest Hippie Songs
YOUTUBE_CHANNEL_ID_1063 = "PLfv2PgfvWgB6csPZO-_ORV5sWW5QBFSao" #Best Country Music
YOUTUBE_CHANNEL_ID_1064 = "" #
YOUTUBE_CHANNEL_ID_1065 = "" #
YOUTUBE_CHANNEL_ID_1066 = "" #
YOUTUBE_CHANNEL_ID_1067 = "" #
YOUTUBE_CHANNEL_ID_1068 = "" #
YOUTUBE_CHANNEL_ID_1069 = "" #
YOUTUBE_CHANNEL_ID_1070 = "" #
YOUTUBE_CHANNEL_ID_1071 = "" #
YOUTUBE_CHANNEL_ID_1072 = "" #
YOUTUBE_CHANNEL_ID_1073 = "" #
YOUTUBE_CHANNEL_ID_1074 = "" #
YOUTUBE_CHANNEL_ID_1075 = "Dj7BHCpX4Ho&t=1299s" #Def Leppard Story
YOUTUBE_CHANNEL_ID_1076 = "3p4MZJsexEs" #Bohemian Rhapsody
YOUTUBE_CHANNEL_ID_1077 = "tgbNymZ7vqY" #Muppets Bohemian Rhapsody
YOUTUBE_CHANNEL_ID_1078 = "" #
YOUTUBE_CHANNEL_ID_1079 = "" #
YOUTUBE_CHANNEL_ID_1080 = "" #
YOUTUBE_CHANNEL_ID_1081 = "" #
YOUTUBE_CHANNEL_ID_1082 = "" #
YOUTUBE_CHANNEL_ID_1083 = "" #
YOUTUBE_CHANNEL_ID_1084 = "" #
YOUTUBE_CHANNEL_ID_1085 = "PLCADQnuKPGspTuE2EpTMx6GfQeC-mRRSm" #Just The Classics (50s N 60s)
YOUTUBE_CHANNEL_ID_1086 = "PLCADQnuKPGsoGdjO_LpyCP3VOjypu5oiS" #Just The Classics (70s N 80s)
YOUTUBE_CHANNEL_ID_1087 = "PLCADQnuKPGspKZ00GdTAVO7Il3fZA9tmA" #Just the Classics (90s)
YOUTUBE_CHANNEL_ID_1088 = "PLCADQnuKPGsr24MUARcNbrVeZg01mnnLS" #Just the 2000s
YOUTUBE_CHANNEL_ID_1089 = "PLCADQnuKPGsoB42trugfpvi0d7W5d9a6g" #Just the 2010s
YOUTUBE_CHANNEL_ID_1090 = "PLCADQnuKPGsp526ZVYkwYY704AVFCnxv6" #Just the 2020s
YOUTUBE_CHANNEL_ID_1091 = "" #
YOUTUBE_CHANNEL_ID_1092 = "" #
YOUTUBE_CHANNEL_ID_1093 = "" #
YOUTUBE_CHANNEL_ID_1094 = "" #
YOUTUBE_CHANNEL_ID_1095 = "" #
YOUTUBE_CHANNEL_ID_1096 = "" #
YOUTUBE_CHANNEL_ID_1097 = "" #
YOUTUBE_CHANNEL_ID_1098 = "" #
YOUTUBE_CHANNEL_ID_1099 = "" #
YOUTUBE_CHANNEL_ID_1100 = "PL3twF-Rby-Ghq9X-x8tXCxQTnVyVrhwAV" #dEF lEPPARD
YOUTUBE_CHANNEL_ID_1101 = "PLFDB39177FBAA68B4" #Metallica
YOUTUBE_CHANNEL_ID_1102 = "PLclODpQJhNz7vm19Ab3k31tUX7dncoup4" #Alice in Chains
YOUTUBE_CHANNEL_ID_1103 = "PLRE0gQNPw5lHFdOosS0BqnrnVTpop7LGm" #Led Zeppelin
YOUTUBE_CHANNEL_ID_1104 = "PLEGyvPj66Teon_Vs7wgoIHXP96vx0Ogpa" #Aerosmith
YOUTUBE_CHANNEL_ID_1105 = "PLgRX2armYujQojmD9rvbLZT_IQd2TlFt5" #Foo Fighters
YOUTUBE_CHANNEL_ID_1106 = "PLYHWXKY-vXeKCXdQTNBKM9pVFIyiBk9P4" #Alter Bridge
YOUTUBE_CHANNEL_ID_1107 = "PLbCezzK_kt_GdBnDxqmjWITt6XNnxs1Eq" #Foreignor
YOUTUBE_CHANNEL_ID_1108 = "PLmJE8NlFiIZMGCFkLCC8FErUuzX7UPaZw" #Bon Jovi
YOUTUBE_CHANNEL_ID_1109 = "PLOTK54q5K4INNXaHKtmXYr6J7CajWjqeJ" #Guns N Roses
YOUTUBE_CHANNEL_ID_1110 = "PLsv6aSJ4_bDtBGsfD6j0e_1LJGTqrbQ_T" #kiss
YOUTUBE_CHANNEL_ID_1111 = "PLIrUP8W6iDAPTf2UZ6a9PkO86Ii1S6Cgp" #Deep Purple
YOUTUBE_CHANNEL_ID_1112 = "PLZGh95p3UpwwKF5C1OW55HHkC3gsePCbi" #Nirvana
YOUTUBE_CHANNEL_ID_1113 = "PLD42F0DBE53E216AF" #Shinedown
YOUTUBE_CHANNEL_ID_1114 = "PLodprRMuxP9_txt9WcJTlzZtFa0JCaZwV" #zz top
YOUTUBE_CHANNEL_ID_1115 = "PL2tMgWgIvcWmvK3JqG7hiSJond0fCcXwr" #Queen
YOUTUBE_CHANNEL_ID_1116 = "PL1UpxsN6ggwAI4az2-ana3xqwQXWTFJvd" #Scorpions
YOUTUBE_CHANNEL_ID_1117 = "PL69E7CB8F976BD5DE" #Van Halen Original
YOUTUBE_CHANNEL_ID_1118 = "PLoopXDarluPBnuxs4PTC55Sc_2ShAXC0i" #Tom Petty
YOUTUBE_CHANNEL_ID_1119 = "PLYXaNxQaVWgRqlHWNiXnrmGpdXCdIQbHm" #Kansas
YOUTUBE_CHANNEL_ID_1120 = "PLVOHQtvxLqQO-K_rNkmTbeHIyZmqiXhiX" #Judas Priest
YOUTUBE_CHANNEL_ID_1121 = "PLCGvSnDzs3ulr_vvPUP1qvas4YB6maY5V" #The Police
YOUTUBE_CHANNEL_ID_1122 = "PLiqnQg9xaQiekzmjoG4-HxGg32F2D8-O4" #INXS
YOUTUBE_CHANNEL_ID_1123 = "PLFw8JYl3SAY7GfEZXekVjN9STaJ7iEoQC" #Dire Straits
YOUTUBE_CHANNEL_ID_1124 = "PL5150F38E402FACE8" #Green Day
YOUTUBE_CHANNEL_ID_1125 = "PL4AF7107E957A240D" #Stone Temple Pilots
YOUTUBE_CHANNEL_ID_1126 = "PLC7B9C3CEACF3407A" #REM
YOUTUBE_CHANNEL_ID_1127 = "PLyVhNY-g2JDjYvQzN1SLYN92XOve9rF0Z" #Sound Garden
YOUTUBE_CHANNEL_ID_1128 = "PLukmsaXDPJie7L7Ihn63HJhA6YMp7tUUr" #Radiohead
YOUTUBE_CHANNEL_ID_1129 = "PLsvoYlzBrLFAJd4hNQSHw1lYjDKeQB_iU" #Coldplay
YOUTUBE_CHANNEL_ID_1130 = "PLaC1ywKS7MyKNuSJbJlbVlISLjSH9OJbt" #Steelheart
YOUTUBE_CHANNEL_ID_1131 = "PLYLwvez_yi_ccUu3pLQM1-1kdKtIvvSRM" #Killswitch Engage
YOUTUBE_CHANNEL_ID_1132 = "PL3Jg9vLWQdmwl6Aiv0CEPNjpxzd-QBHlC" #Light The Torch
YOUTUBE_CHANNEL_ID_1133 = "PLU0xJXuoY34pFpLh_mamzeMFZbqElg5h3" #Hoobastank
YOUTUBE_CHANNEL_ID_1134 = "PLAC9127A72919F8DC" #The White Stripes
YOUTUBE_CHANNEL_ID_1135 = "PLu4DnfQbWb3OSbxJNx8K-bzvHpJ7q-C4V" #Creed
YOUTUBE_CHANNEL_ID_1136 = "PL4kdLaIbJNcQee1Fjchc1LnyjDcnTqM9R" #The Cult
YOUTUBE_CHANNEL_ID_1137 = "PLFMns86uumjjX0zHm2hzKi_Yr18YzV5qr" #Nickelback
YOUTUBE_CHANNEL_ID_1138 = "PLFB8E2A055586144C" #3 Doors Down
YOUTUBE_CHANNEL_ID_1139 = "PLvOVWwFA2FHxM7Q9SQ_sT7kc3mz_Xi09x" #Incubus
YOUTUBE_CHANNEL_ID_1140 = "PL08230BC08BF305AC" #Linkin Park
YOUTUBE_CHANNEL_ID_1141 = "PLcaPdH-BvlV_iFstdUjS2XeTQVNGynR82" #Kings of Leon
YOUTUBE_CHANNEL_ID_1142 = "PLk_uOPdELs45lClRTh0uDRzWpCk9Kv4k9" #Hinder
YOUTUBE_CHANNEL_ID_1143 = "PLUueilRKpIbK9zp26cjNWSovPLoMbkvoA" #Journey
YOUTUBE_CHANNEL_ID_1144 = "PLLkyIDIYoOXrGYIRxYZ2p7tyuhNGBYa12" #Reo Speedwagon
YOUTUBE_CHANNEL_ID_1145 = "PL16255659F29D1D5A" #Bush
YOUTUBE_CHANNEL_ID_1146 = "PLHU-FwksMi7J386typXGhxaer-lczpB1w" #Joan Jett
YOUTUBE_CHANNEL_ID_1147 = "PLaPEstx8t-doXEZ1Xteugm4Mnb2svrzgP" #Bryan Adams
YOUTUBE_CHANNEL_ID_1148 = "PLwVBNowUqkUXh0IQfDCa1A63nzG9WTO4V" #Greta Van Fleet
YOUTUBE_CHANNEL_ID_1149 = "" #
YOUTUBE_CHANNEL_ID_1150 = "" #
YOUTUBE_CHANNEL_ID_1151 = "" #
YOUTUBE_CHANNEL_ID_1152 = "" #
YOUTUBE_CHANNEL_ID_1153 = "" #
YOUTUBE_CHANNEL_ID_1154 = "" #
YOUTUBE_CHANNEL_ID_1155 = "" #
YOUTUBE_CHANNEL_ID_1156 = "" #
YOUTUBE_CHANNEL_ID_1157 = "" #
YOUTUBE_CHANNEL_ID_1158 = "" #
YOUTUBE_CHANNEL_ID_1159 = "" #
YOUTUBE_CHANNEL_ID_1160 = "" #
YOUTUBE_CHANNEL_ID_1161 = "" #
YOUTUBE_CHANNEL_ID_1162 = "" #
YOUTUBE_CHANNEL_ID_1163 = "" #
YOUTUBE_CHANNEL_ID_1164 = "" #
YOUTUBE_CHANNEL_ID_1165 = "" #
YOUTUBE_CHANNEL_ID_1166 = "" #
YOUTUBE_CHANNEL_ID_1167 = "" #
YOUTUBE_CHANNEL_ID_1168 = "" #
YOUTUBE_CHANNEL_ID_1169 = "" #
YOUTUBE_CHANNEL_ID_1170 = "" #
YOUTUBE_CHANNEL_ID_1171 = "" #

YOUTUBE_CHANNEL_ID_1200 = "PLjeNJVhaXPVS7ImYEp6KQQM_lLKmiD1jt" #Dan Lucas: The Voice Seniors
YOUTUBE_CHANNEL_ID_1201 = "PLRxaYJtw63qQmjN7SzStR36J-o4C09jkU" #The Voice Seniors Season I
YOUTUBE_CHANNEL_ID_1202 = "PLCADQnuKPGsoTno_cf2rDQcqXc_63GYAt" #The Voice Kids Mix Playlist
YOUTUBE_CHANNEL_ID_1203 = "PLCADQnuKPGsqXozBi9JwlXVJdWIN64sNG" #The Voice Kids Rock Playlist
YOUTUBE_CHANNEL_ID_1204 = "PL_NKWLcpSrYP8kMDLxzuOH4NN8Ph_AbmK" #The Voice Kids 2020 Blind Auditions
YOUTUBE_CHANNEL_ID_1205 = "PL_NKWLcpSrYPUhIIwAsxBbsqKSySbkZ7k" #The Voice Kids 2020 Battles
YOUTUBE_CHANNEL_ID_1206 = "PL_NKWLcpSrYNk11bGIehSRolYK9vq1aJR" #The Voice Kids 2020 Sing Offs
YOUTUBE_CHANNEL_ID_1207 = "PL_NKWLcpSrYNGJkeg8LuDjJTlkt9IyCC1" #The Voice Kids 2020 Finale
YOUTUBE_CHANNEL_ID_1208 = "PLCADQnuKPGspU-0CSW7xtUlS3s00dOUJ9" #The Voice Seniors Playlist
YOUTUBE_CHANNEL_ID_1209 = "PLCADQnuKPGspLZ11M_RXAnR91T7YrtDSd" #The Voice Seniors Highlights
YOUTUBE_CHANNEL_ID_1210 = "PLCADQnuKPGsrfg0Ijb8MhBI-3Mfu6QdIa" #The Voice Rock Playlist
YOUTUBE_CHANNEL_ID_1211 = "PLCADQnuKPGsoXLYMw3a1rc8bAQszmwy5Z" #The Voice Mix Playlist
YOUTUBE_CHANNEL_ID_1212 = "" #
YOUTUBE_CHANNEL_ID_1213 = "" #
YOUTUBE_CHANNEL_ID_1214 = "" #
YOUTUBE_CHANNEL_ID_1215 = "" #
YOUTUBE_CHANNEL_ID_1216 = "" #
YOUTUBE_CHANNEL_ID_1217 = "" #
YOUTUBE_CHANNEL_ID_1218 = "" #
YOUTUBE_CHANNEL_ID_1219 = "" #
YOUTUBE_CHANNEL_ID_1220 = "" #

YOUTUBE_CHANNEL_ID_1310 = "" #
YOUTUBE_CHANNEL_ID_1311 = "" #
YOUTUBE_CHANNEL_ID_1312 = "" #
YOUTUBE_CHANNEL_ID_1313 = "" #
YOUTUBE_CHANNEL_ID_1314 = "" #
YOUTUBE_CHANNEL_ID_1315 = "" #
YOUTUBE_CHANNEL_ID_1316 = "" #
YOUTUBE_CHANNEL_ID_1317 = "" #
YOUTUBE_CHANNEL_ID_1318 = "" #
YOUTUBE_CHANNEL_ID_1319 = "" #
YOUTUBE_CHANNEL_ID_1320 = "" #
YOUTUBE_CHANNEL_ID_1321 = "" #
YOUTUBE_CHANNEL_ID_1322 = "" #
YOUTUBE_CHANNEL_ID_1323 = "" #
YOUTUBE_CHANNEL_ID_1324 = "" #
YOUTUBE_CHANNEL_ID_1325 = "PLNFmmVv2YeZ499nqXLK9LvmVW0q2mxl2l" #Music Movies And Docs
YOUTUBE_CHANNEL_ID_1326 = "PLSc6r-00Q8xzS9yLjJ-wCA12CSyASHYlh" #Music And Bands Documentary
YOUTUBE_CHANNEL_ID_1327 = ""                 #
YOUTUBE_CHANNEL_ID_1328 = "PL7jBOGah2-gzn2F7eTjGmsZN0fAPPc7wj" #Music Documentaries
YOUTUBE_CHANNEL_ID_1329 = "PL4upTjMb8fhYI5EY8bMSjafg9lC3vdUat" #More Music Documentary
YOUTUBE_CHANNEL_ID_1330 = "PL5Ssj_AykzW1pOdGYQRMixPmVFi5N0SYS" #Full Music Documentaries
YOUTUBE_CHANNEL_ID_1331 = "PLpyvM1VTKUKJQfs3l0yQ2bB8aWC29BHPF" #Music Documentary: Rock
YOUTUBE_CHANNEL_ID_1332 = "PLCKx3ns9oQR0kEaS-ZOiygKNSmKi9WApw" #Music Documentary
YOUTUBE_CHANNEL_ID_1333 = "PLJJLc8KaL25JcytazVkjemXNwrCAMm0Gi" #More Music Docs
YOUTUBE_CHANNEL_ID_1334 = "PL1E9CF53D6FF4AE18"                 #Jazz: A History of Americas Music
YOUTUBE_CHANNEL_ID_1335 = "PLOvXkB5eFXm7lfggMnEO1TWzENy-0YhVP" #BBC mucic docs
YOUTUBE_CHANNEL_ID_1336 = "PL3EFF4269AE644C28" #                PUNK music docs
YOUTUBE_CHANNEL_ID_1337 = "PL84C83DBD88AD79E4" #                Hip Hop Docs
YOUTUBE_CHANNEL_ID_1338 = "" #
YOUTUBE_CHANNEL_ID_1339 = "" #
YOUTUBE_CHANNEL_ID_1340 = "" #
YOUTUBE_CHANNEL_ID_1341 = "" #
YOUTUBE_CHANNEL_ID_1342 = "" #
YOUTUBE_CHANNEL_ID_1343 = "" #
YOUTUBE_CHANNEL_ID_1344 = "" #
YOUTUBE_CHANNEL_ID_1345 = "" #
YOUTUBE_CHANNEL_ID_1346 = "" #
YOUTUBE_CHANNEL_ID_1347 = "" #
YOUTUBE_CHANNEL_ID_1348 = "" #
YOUTUBE_CHANNEL_ID_1349 = "" #
YOUTUBE_CHANNEL_ID_1360 = "PLI0NxXh5RQAnMedqVNzJSo7ohKRASd1TT" #Musical Movies
YOUTUBE_CHANNEL_ID_1361 = "PL8zlx4BqIHThGh2vDxHgeesdj1kbRv-kb" #More Musical Movies
YOUTUBE_CHANNEL_ID_1362 = "PLZhDVfdrWFKBR378OiCLJufgwO8qEHERV" #Comedy Musicals And Shorts
YOUTUBE_CHANNEL_ID_1363 = "PLvLD9ZFEYs5XdaHs-cBLAz45hQH2PScww" #Movies: Musicals
YOUTUBE_CHANNEL_ID_1364 = "PLgAe4sgN2_HVe0iwbm3xEf5tBZ_9P6nfd" #Classic Musicals And Shorts
YOUTUBE_CHANNEL_ID_1365 = "PLHsKdBiweGhqHgHHgRXZ5qNXrr6rFNxAi" #Moms Musical Movies
YOUTUBE_CHANNEL_ID_1366 = "PLXekjrSkI4zes73Av9LsAfYRw8R7HVyaW" #Devo Classic Musicals And Shorts
YOUTUBE_CHANNEL_ID_1367 = "PL_8EDYaWz7p4n1NZDP2COWQ2D-bnVjz3L" #Musical: Movies
YOUTUBE_CHANNEL_ID_1368 = "PL9AeeY5wUbUSqamWYNJmi2N8mixcebxEh" #Country Music Movies
YOUTUBE_CHANNEL_ID_1369 = "PLICbIwv5wDu6w7TpP93Jff3mM7Dm5FuE6" #Musical Movies And Plays
YOUTUBE_CHANNEL_ID_1370 = "PL24f2DlOqrQTFvTMDiE0O0MNQ0F39ocdE" #Short Musical Films
YOUTUBE_CHANNEL_ID_1371 = "PLxSCCw9R-urxC2gHfC8oTZiP6IUTXMQRT" #Full Musicals - Bootlegs
YOUTUBE_CHANNEL_ID_1372 = "PLI_GqCCthXkFL1GHhh-96Ja6gctWDRsYp" #Musical Films
YOUTUBE_CHANNEL_ID_1373 = "" #
YOUTUBE_CHANNEL_ID_1374 = "" #
YOUTUBE_CHANNEL_ID_1375 = "" #
YOUTUBE_CHANNEL_ID_1376 = "" #
YOUTUBE_CHANNEL_ID_1377 = "" #
YOUTUBE_CHANNEL_ID_1378 = "" #
YOUTUBE_CHANNEL_ID_1379 = "" #
YOUTUBE_CHANNEL_ID_1380 = "" #
YOUTUBE_CHANNEL_ID_1381 = "" #
YOUTUBE_CHANNEL_ID_1382 = "" #
YOUTUBE_CHANNEL_ID_1383 = "" #
YOUTUBE_CHANNEL_ID_1384 = "" #
YOUTUBE_CHANNEL_ID_1385 = "" #
YOUTUBE_CHANNEL_ID_1386 = "" #
YOUTUBE_CHANNEL_ID_1387 = "" #
YOUTUBE_CHANNEL_ID_1388 = "PLCxhTelqvqc9M9sk-t8y2QlEG8t9xuFvV" #The Voice UK Best Battles
YOUTUBE_CHANNEL_ID_1389 = "PLo92kHqB-7o63IVb6IwT87G51BECBXPuE" #The Voice Australia S2
YOUTUBE_CHANNEL_ID_1390 = "PL0PvATFQmFzltQinQ-Wl4tMV6Mnv97-xQ" #Ready, Steady, Go: 60s British
YOUTUBE_CHANNEL_ID_1391 = "PLlp-fMyQY0EXLN_CfFeYiR1Bm8yG-vG1n" #Music TV Shows: The Voice
YOUTUBE_CHANNEL_ID_1392 = "PLSNPpQBvTTknzxbcUAjhNHh4x0SAiB_9g" #TV: The Midnight Special
YOUTUBE_CHANNEL_ID_1393 = "PLP7_eREdOsFymCNT7mGro-D2Fz2QTxfPj" #The Beat Club: German
YOUTUBE_CHANNEL_ID_1394 = "PLHXo2Ss6Lgp4b2Z3hEfkKY9X3qd5PIV5x" #Solid Gold Tv Show
YOUTUBE_CHANNEL_ID_1395 = "PLl4g9yPseuEXL2CM7yjVSjOG_Xdve2Q5f" #TV: The Voice UK
YOUTUBE_CHANNEL_ID_1396 = "PLq6vSxwqHE1FaxJQLFHvGiz5MzDQyekMs" #The Voice UK Blind Auditions
YOUTUBE_CHANNEL_ID_1397 = "PL_NKWLcpSrYOo6De62ZwajE6bWZWN3Vpj" #The Voice Kids: 2015 Blind Auditions
YOUTUBE_CHANNEL_ID_1398 = "PL8yQXVwY4poEu7dZ-xw7mCLpLuSMe68ZE" #The Voice Season 2
YOUTUBE_CHANNEL_ID_1399 = "PLltaES3sQDz-wMlEf7eXlMMfdb21eE5il" #The Voice Season 3
YOUTUBE_CHANNEL_ID_1400 = "PLPglX4LjfEan-B_pm6saR3w8Igdn2tWA1" #The Voice UK Series 5
YOUTUBE_CHANNEL_ID_1401 = "" #
YOUTUBE_CHANNEL_ID_1402 = "" #
YOUTUBE_CHANNEL_ID_1403 = "" #
YOUTUBE_CHANNEL_ID_1404 = "" #
YOUTUBE_CHANNEL_ID_1405 = "" #
YOUTUBE_CHANNEL_ID_1406 = "" #
YOUTUBE_CHANNEL_ID_1407 = "" #
YOUTUBE_CHANNEL_ID_1408 = "" #
YOUTUBE_CHANNEL_ID_1409 = "" #
YOUTUBE_CHANNEL_ID_1410 = "" #
YOUTUBE_CHANNEL_ID_1411 = "" #
YOUTUBE_CHANNEL_ID_1412 = "" #
YOUTUBE_CHANNEL_ID_1413 = "PLtclzMEXudoOKKQkaoZ2S5-NY023gzFIR" #Best Of George Michaels
YOUTUBE_CHANNEL_ID_1414 = "PLVJc3MuCAojx2f5NDkfY9roz6fqONgq7J" #All Time Most Viewed
YOUTUBE_CHANNEL_ID_1415 = "PL3oW2tjiIxvRDymF6SFf7t4xfDbtRQxlt" #Country Music Videos
YOUTUBE_CHANNEL_ID_1416 = "PL300C32DA374417AA"                 #Classic Rock Videos
YOUTUBE_CHANNEL_ID_1417 = "musicvault"                         #The Music Vault
YOUTUBE_CHANNEL_ID_1418 = "PLI_7Mg2Z_-4JiTe-Mcr9XmxXJLQ53Pppq" #New Music Videos
YOUTUBE_CHANNEL_ID_1419 = "PLs47-_7pQr-hxk0_qmR3jURhGi5QEU0lH" #Weird Al Yankovic
YOUTUBE_CHANNEL_ID_1420 = "PLuRo0Z9OfQyMBY76Ak-WviDtS4FBcZ37d" #Top 100 Hip-Hop Video
YOUTUBE_CHANNEL_ID_1421 = "PL3oW2tjiIxvQW6c-4Iry8Bpp3QId40S5S" #All Time Top Country
YOUTUBE_CHANNEL_ID_1422 = "PLMZxug3Hi7FZ0kmdwlZYP7vXuk1R-yOOz" #Country Music Playlist
YOUTUBE_CHANNEL_ID_1423 = "PL330A461779A9106A"                 #Christian Music Video
YOUTUBE_CHANNEL_ID_1424 = "PLvHxQKA0OzOypmOX3EDfItl5zEcmrgs_t" #60s Music Playlist
YOUTUBE_CHANNEL_ID_1425 = "PLw6p6PA8M2mikVwEESBCyR79eoGYfA2-A" #60s-70s Heavy Metal
YOUTUBE_CHANNEL_ID_1426 = "PLGBuKfnErZlAkaUUy57-mR97f8SBgMNHh" #70s Hits Playlist
YOUTUBE_CHANNEL_ID_1427 = "PLw6p6PA8M2mjjF4eKbEKdcKVb72FAbAUZ" #70s Music Playlist
YOUTUBE_CHANNEL_ID_1428 = "PLw6p6PA8M2mjXWPBMXGkFpvCHXNx6YxdF" #70s Punk Rock Videos
YOUTUBE_CHANNEL_ID_1429 = "" #
YOUTUBE_CHANNEL_ID_1430 = "PLjB-wurbnZxUY8WEq6iu-A45Bt_EjXvDX" #80s Music Playlist
YOUTUBE_CHANNEL_ID_1431 = "PLw6p6PA8M2miu0w4K1g6vQ1BHUBeyM4_-" #80s-90s Heavy Metal
YOUTUBE_CHANNEL_ID_1432 = "PLE6rhv8iI_vJ48CbdqZqnr-6LT4A_Lxtq" #90s Music Playlist
YOUTUBE_CHANNEL_ID_1433 = "PLeqcGFY5qNZ5hWhvci-eK36pwpEcZGvQ0" #90s Hip Hop N R&B
YOUTUBE_CHANNEL_ID_1434 = "PLyjgHc47unfT3BIZo5uEt2a-2TWKy54sU" #90s-00s Playlist
YOUTUBE_CHANNEL_ID_1435 = "PLpuDUpB0osJmZQ0a3n6imXirSu0QAZIqF" #2000s Hits Playlist
YOUTUBE_CHANNEL_ID_1436 = "PLw6p6PA8M2mj0K37EALCSAtkFVXyVPU80" #2010s Heavy Metal
YOUTUBE_CHANNEL_ID_1437 = "" #
YOUTUBE_CHANNEL_ID_1438 = "" #
YOUTUBE_CHANNEL_ID_1439 = "" #
YOUTUBE_CHANNEL_ID_1440 = "" #
YOUTUBE_CHANNEL_ID_1441 = "" #
YOUTUBE_CHANNEL_ID_1442 = "" #
YOUTUBE_CHANNEL_ID_1443 = "" #
YOUTUBE_CHANNEL_ID_1444 = "" #
YOUTUBE_CHANNEL_ID_1445 = "" #
YOUTUBE_CHANNEL_ID_1446 = "" #
YOUTUBE_CHANNEL_ID_1447 = "" #
YOUTUBE_CHANNEL_ID_1448 = "" #
YOUTUBE_CHANNEL_ID_1449 = "cheaptrick"               #Cheap Trick Channel
YOUTUBE_CHANNEL_ID_1450 = "UCiMhD4jzUqG-IgPzUmmytRQ" #Queen Official Channel
YOUTUBE_CHANNEL_ID_1451 = "linkinparktv"             #Linkin Park Channel
YOUTUBE_CHANNEL_ID_1452 = "UCHKSayVT2Ks-gQBXmMLGTag" #Soundgarden Channel
YOUTUBE_CHANNEL_ID_1453 = "UCbulh9WdLtEXiooRcYK7SWw" #The Metallica Channel
YOUTUBE_CHANNEL_ID_1454 = "UCb0vzLwvr7xbJgdqMzejDhw" #The Cranberries Channel
YOUTUBE_CHANNEL_ID_1455 = "UCP_k5WdrOOuWaThTU6MDonw" #David Gilmour Channel
YOUTUBE_CHANNEL_ID_1456 = "gratefuldead"             #Grateful Dead Channel
YOUTUBE_CHANNEL_ID_1457 = "UCBxdHQVOaZhUOIj_3gt2FYw" #The Aerosmith Channel
YOUTUBE_CHANNEL_ID_1458 = "UCsFPCqkPsesPa8XxN1pJx-w" #The Band Heart Channel
YOUTUBE_CHANNEL_ID_1459 = "UCB0JSO6d5ysH2Mmqz5I9rIw" #AC-DC Official Channel
YOUTUBE_CHANNEL_ID_1460 = "UClQT6Vnsm6BUm0I5kR26EkQ" #The Pearl Jam Channel
YOUTUBE_CHANNEL_ID_1461 = "UCvYomLPMwUr1FAXRMGhVfCQ" #The Tom Petty Channel
YOUTUBE_CHANNEL_ID_1462 = "UC4JeRiQvPQ_nb1BZWjk9QoA" #Phil Collins Channel
YOUTUBE_CHANNEL_ID_1463 = "UCe3JCin4Gnv9azlWnAs5keg" #Ozzie Osbourne Channel
YOUTUBE_CHANNEL_ID_1464 = "UCq2g_Vcu3J1OwNRmdTNoxYA" #Motley Crue Channel
YOUTUBE_CHANNEL_ID_1465 = "UCyOw2FDjfQOFQH7paKxNVvA" #The Kiss Channel
YOUTUBE_CHANNEL_ID_1466 = "UCr79-QZv1_VGlxVWLc28xrQ" #The Foreigner Channel
YOUTUBE_CHANNEL_ID_1467 = "UCP-tFf_VMQzhyeKMONL1KvQ" #The Creed Channel
YOUTUBE_CHANNEL_ID_1468 = "UCkBwnm7GOfYHsacwUjriC-w" #Bon Jovi Channel
YOUTUBE_CHANNEL_ID_1469 = "UCv42RmpB6iwadGz6n818l6w" #Alter Bridge Channel
YOUTUBE_CHANNEL_ID_1470 = "UCv7Bgr5Mq-dPYu-Ol4AocEA" #Shinedown Channel
YOUTUBE_CHANNEL_ID_1471 = "UCZjBqZjGsmI5OAVsLSroaWQ" #Def Leppard Channel
YOUTUBE_CHANNEL_ID_1472 = "UC48vpdaG8NDvEGLj11XPPZQ" #Judas Priest Channel
YOUTUBE_CHANNEL_ID_1473 = "UCi2KNss4Yx73NG0JARSFe0A" #Foo Fighters Channel
YOUTUBE_CHANNEL_ID_1474 = "UC4gPNusMDwx2Xm-YI35AkCA" #The U2 Channel

YOUTUBE_CHANNEL_ID_1475 = "UCqECaJ8Gagnn7YCbPEzWH6g" #Taylor Swift Channel
YOUTUBE_CHANNEL_ID_1476 = "UC9CoOnJkIBMdeijd9qYoT_g" #Ariana Grande Channel
YOUTUBE_CHANNEL_ID_1477 = "UC5-gWZXAQqSGVfPHkA7NRiQ" #Bebe Rexha Channel
YOUTUBE_CHANNEL_ID_1478 = "UCBVjMGOIkavEAhyqpxJ73Dw" #Maroon 5 Channel
YOUTUBE_CHANNEL_ID_1479 = "UCm1s2VS9BdyXL9FU4a-W_cQ" #Nipsey Hustle Channel
YOUTUBE_CHANNEL_ID_1480 = "UCxMAbVFmxKUVGAll0WVGpFw" #The Cardi B Channel
YOUTUBE_CHANNEL_ID_1481 = "UC8rVJyj4zE0S9-sccMLifIA" #Lil Dicky Channel
YOUTUBE_CHANNEL_ID_1482 = "UCkXgEcpoTE4tHsebYBouWpA" #Meghan Trainor Channel
YOUTUBE_CHANNEL_ID_1483 = "UCuHzBCaKmtaLcRAOoazhCPA" #The Beyonce Channel
YOUTUBE_CHANNEL_ID_1484 = "UCcgqSM4YEo5vVQpqwN-MaNw" #The Rihanna Channel
YOUTUBE_CHANNEL_ID_1485 = "UCYvmuw-JtVrTZQ-7Y4kd63Q" #Katy Perry Channel
YOUTUBE_CHANNEL_ID_1486 = "UCByOQJjav0CUDwxCk-jVNRQ" #The Drake Channel
YOUTUBE_CHANNEL_ID_1487 = "UCNL1ZadSjHpjm4q9j2sVtOA" #Lady Gaga Channel
YOUTUBE_CHANNEL_ID_1488 = "UCVp3nfGRxmMadNDuVbJSk8A" #Wiz Khalifa Channel
YOUTUBE_CHANNEL_ID_1489 = "UC_eQfAQjj6mYj92l3SBmIdg" #Fetty Wap Channel
YOUTUBE_CHANNEL_ID_1490 = "UC8zJedg1f4sKnyuHWeS6vyw" #50 Cent Channel
YOUTUBE_CHANNEL_ID_1491 = "UCT41vlFeZ_asAUCY7BOiJVQ" #Wham TV Channel
YOUTUBE_CHANNEL_ID_1492 = "UCBFaOy1_APEXEyA6Gws_Y1g" #Black Eyed Peas Channel
YOUTUBE_CHANNEL_ID_1493 = "UC-BN_2GM8EEd6w03EHyvtmw" #The Yo Gotti Channel
YOUTUBE_CHANNEL_ID_1494 = "UC3NFtmTQ_bt87KOXx4QR3LA" #The Ashanti Channel
YOUTUBE_CHANNEL_ID_1495 = "UCurpiDXSkcUbgdMwHNZkrCg" #Mariah Carey Channel
YOUTUBE_CHANNEL_ID_1496 = "UC2064-GFZ1y5NYZuUGX4iEA" #Destinys Child Channel
YOUTUBE_CHANNEL_ID_1497 = "UCK5X3f0fxO4YnVKVZP8p6hg" #Alicia Keys Channel
YOUTUBE_CHANNEL_ID_1498 = "UCaNrhBiXsXIM2epDl_kEzgQ" #The Usher Channel
YOUTUBE_CHANNEL_ID_1499 = "" #
YOUTUBE_CHANNEL_ID_1500 = "UCvtkFm0XlCLqyvtP7UpqAoA" #The Ne-Yo Channel

YOUTUBE_CHANNEL_ID_1925 = "UC-9-kyTW8ZkZNDHQJ6FgpwQ"           #Music Channel Mix
YOUTUBE_CHANNEL_ID_1926 = "smokeybarz"                         #SBTV Music Channel
YOUTUBE_CHANNEL_ID_1927 = "" #
YOUTUBE_CHANNEL_ID_1928 = "UCOJZ1tna8yj8mAEITPkHNCQ"           #Slipknot Channel
YOUTUBE_CHANNEL_ID_1929 = "UCqC_GY2ZiENFz2pwL0cSfAw"           #Green Day Channel
YOUTUBE_CHANNEL_ID_1930 = "UCX2_tsfS1lWaNg26UUuWrxA"           #Greta Van Fleet
YOUTUBE_CHANNEL_ID_1931 = "UCM-CWGUijAC-8idv6k6Fygw"           #Depeche Mode Channel
YOUTUBE_CHANNEL_ID_1932 = "UCocfdCiKujljqcGC-STMsCQ"           #Stone Temple Pilots
YOUTUBE_CHANNEL_ID_1933 = "UCE8NoMFnai3tTuwdiQJ-78A"           #Skillet Channel
YOUTUBE_CHANNEL_ID_1934 = "HDPinkFloyd"                        #Pink Floyd Channel
YOUTUBE_CHANNEL_ID_1935 = "acdc"                               #AC/DC Channel
YOUTUBE_CHANNEL_ID_1936 = "DefLeppardOfficial"                 #Def Leppard Channel
YOUTUBE_CHANNEL_ID_1937 = "deeppurpleos"                       #Deep Purple Channel
YOUTUBE_CHANNEL_ID_1938 = "UC4gPNusMDwx2Xm-YI35AkCA"           #Music: U2 Channel
YOUTUBE_CHANNEL_ID_1939 = "UCw28dvU7NbdZPF9kEPrT7aA"           #Rival Sons Channel
YOUTUBE_CHANNEL_ID_1940 = "UC2dZ0a6uJJHWMoF7oah6zew"           #The Band Camino
YOUTUBE_CHANNEL_ID_1941 = "UCsxtEOcwpVO9Rnw93Fuv2pQ"           #Dirty Honey Channel
YOUTUBE_CHANNEL_ID_1942 = "UCt_naO54DunfncZ0UO1rHbw"           #The Crobot Channel
YOUTUBE_CHANNEL_ID_1943 = "" #
YOUTUBE_CHANNEL_ID_1944 = "alyankovic"                         #Weird Al Yankovic
YOUTUBE_CHANNEL_ID_1945 = "UCipLjr-h2iaEBWMJVfK2e2A"           #Lynyrd Skynyrd Channel
YOUTUBE_CHANNEL_ID_1946 = "UCNL1ZadSjHpjm4q9j2sVtOA"           #Lady Gaga Channel
YOUTUBE_CHANNEL_ID_1947 = "UCcgqSM4YEo5vVQpqwN-MaNw"           #Rihanna Channel
YOUTUBE_CHANNEL_ID_1948 = "" #
YOUTUBE_CHANNEL_ID_1949 = "UCgffc95YDBlkGrBAJUHUmXQ"           #Britney Spears Channel
YOUTUBE_CHANNEL_ID_1950 = "" #
YOUTUBE_CHANNEL_ID_1951 = "UCEuOwB9vSL1oPKGNdONB4ig"           #Red Hot Chili Peppers
YOUTUBE_CHANNEL_ID_1952 = "" #
YOUTUBE_CHANNEL_ID_1953 = "UCZU9T1ceaOgwfLRq7OKFU4Q"           #Linkin Park Channel
YOUTUBE_CHANNEL_ID_1954 = "" #
YOUTUBE_CHANNEL_ID_1955 = "UCdIs5dRqgZ1IWOdLZimHL_w"           #Lenny Kravitz Channel
YOUTUBE_CHANNEL_ID_1956 = "UCIak6JLVOjqhStxrL1Lcytw"           #Gun N Roses Channel
YOUTUBE_CHANNEL_ID_1957 = "UCjwhEPNX5rsU6gl_8qZMQZg"           #Kid Rock Channel
YOUTUBE_CHANNEL_ID_1958 = "UCi2KNss4Yx73NG0JARSFe0A"           #Foo Fighters Channel
YOUTUBE_CHANNEL_ID_1959 = "UCK9X9JACEsonjbqaewUtICA"           #Alice In Chains
YOUTUBE_CHANNEL_ID_1960 = "UCB_Z6rBg3WW3NL4-QimhC2A"           #Rolling Stones Channel
YOUTUBE_CHANNEL_ID_1961 = "UCPVhZsC2od1xjGhgEc2NEPQ"           #Vevo Playlists Channel
YOUTUBE_CHANNEL_ID_1962 = "" #
YOUTUBE_CHANNEL_ID_1963 = "UCxMAbVFmxKUVGAll0WVGpFw"           #Cardi B Channel
YOUTUBE_CHANNEL_ID_1964 = "" #
YOUTUBE_CHANNEL_ID_1965 = "UC-OO324clObi3H-U0bP77dw"           #Snoop Dogg Channel
YOUTUBE_CHANNEL_ID_1966 = "UCaKZA66vM_TUpetUNohmR0A"           #Led Zeppelin Channel
YOUTUBE_CHANNEL_ID_1967 = "UC49r4GNHHpc-eQ9hmD2Rg6A"           #The Eagles Channel
YOUTUBE_CHANNEL_ID_1968 = "UC-MMd_17p3qNSTVbLdiYzow"           #Rap Party Channel
YOUTUBE_CHANNEL_ID_1969 = "UC6urGiDCfmUg13r1RHSneGA"           #Red Music Channel
YOUTUBE_CHANNEL_ID_1970 = "blackeyedpeasvideo"                 #Black Eyed Peas
YOUTUBE_CHANNEL_ID_1971 = "VHTelevision"                       #Van Halen Channel
YOUTUBE_CHANNEL_ID_1972 = "" #
YOUTUBE_CHANNEL_ID_1973 = "thebeatles"                         #The Beatles Channel
YOUTUBE_CHANNEL_ID_1974 = "UC7eaRqtonpyiYw0Pns0Au_g"           #The REM Channel
YOUTUBE_CHANNEL_ID_1975 = "UCEqrtYLjy1o4hvaUI0J530w"           #Jimi Hendrix Channel
YOUTUBE_CHANNEL_ID_1976 = "AustinCityLimitsTV"                 #Austin City Limits Channel
YOUTUBE_CHANNEL_ID_1977 = "PAULMCCARTNEY"                      #Paul McCartney Channel
YOUTUBE_CHANNEL_ID_1978 = "BobDylanVEVO"                       #Bob Dylan On Vevo
YOUTUBE_CHANNEL_ID_1979 = "montreuxjazzvideos"                 #Montreux Jazz Video Channel
YOUTUBE_CHANNEL_ID_1980 = "" #
YOUTUBE_CHANNEL_ID_1981 = ""           #
YOUTUBE_CHANNEL_ID_1982 = "" #
YOUTUBE_CHANNEL_ID_1983 = "" #
YOUTUBE_CHANNEL_ID_1984 = "" #
YOUTUBE_CHANNEL_ID_1985 = "" #
YOUTUBE_CHANNEL_ID_1986 = "" #
YOUTUBE_CHANNEL_ID_1987 = "" #
YOUTUBE_CHANNEL_ID_1988 = "" #
YOUTUBE_CHANNEL_ID_1989 = "" #
YOUTUBE_CHANNEL_ID_1990 = "" #
YOUTUBE_CHANNEL_ID_1991 = "" #
YOUTUBE_CHANNEL_ID_1992 = "" #
YOUTUBE_CHANNEL_ID_1993 = "" #
YOUTUBE_CHANNEL_ID_1994 = "PLCADQnuKPGspnE6Um2eZV6rcr3XFht8kv" #20 Hard Rock Songs
YOUTUBE_CHANNEL_ID_1995 = "PLCADQnuKPGsq-IywecdICY7zLE3IHkC1g" #20 This Side Of Rock
YOUTUBE_CHANNEL_ID_1996 = "PLCADQnuKPGsqqSmzzW9DKvbTdAi_IhR5Y" #20 Slow Rock Songs
YOUTUBE_CHANNEL_ID_1997 = "PLCADQnuKPGsq0QJu_zN6_V5YmtIuz63Mb" #20 Best Blues Rock
YOUTUBE_CHANNEL_ID_1998 = "PLCADQnuKPGsrUx_Drf7RMBTT3piu30v9_" #20 rock ballad
YOUTUBE_CHANNEL_ID_1999 = "PLCADQnuKPGsoOKO9bSJnRMFLRsROHHQgB" #20 great rock songs
	
#@route(mode='just2000s')
def just2000s():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Just the 2000s[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1088+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_2000s.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Just the 2010s[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1089+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_2000s.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Just the 2020s[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1090+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_2000s.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)
	
#@route(mode='justclassics')
def justClassics():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Just the Classics 50s - 60s[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1085+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Just the Classics 70s - 80s[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1086+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_classic.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Just the Classics 90s[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1087+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_classic.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)
	
#@route(mode='thevoice')
def theVoice():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids Rock Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1203+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids Mix Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1202+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids 2020 Blind Auditions[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1204+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids 2020 Battles[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1205+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids 2020 Sing Offs[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1206+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids 2020 Finale[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1207+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Rock Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1210+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Mix Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1211+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Seniors Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1208+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dan Lucas: The Voice Seniors[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1200+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Seniors Highlights[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1209+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_voice.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)
	
#@route(mode='oneclickrock')
def OneClickRock():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]David Gilmour Live at Pompeii[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1024+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Metallica Song Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1101+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Def Leppard Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1100+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AC-DC Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1030+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]U2 Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1032+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Alice in Chains Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1102+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Led Zeppelin Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1103+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Aerosmith Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1104+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Foo Fighters Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1105+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Alter Bridge Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1106+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Foreigner Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1107+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bon Jovi Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1108+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Guns N Roses Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1109+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kiss Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1110+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Deep Purple Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1111+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nirvana Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1112+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shinedown Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1113+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]ZZ Top Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1114+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Queen Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1115+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Scorpions Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1116+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Van Halen Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1117+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Tom Petty N the Heartbreakers[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1118+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kansas Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1119+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Judas Priest Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1120+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Police Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1121+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]INXS Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1122+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dire Straits Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1123+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Alice Cooper Greatest Hits[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1050+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Weird Al Yankovic Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1419+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Green Day Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1124+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Stone Temple Pilots Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1125+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)


	Add_Dir(
		name="[COLOR white][B]REM Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1126+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)


	Add_Dir(
		name="[COLOR white][B]Sound Garden Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1127+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)


	Add_Dir(
		name="[COLOR white][B]Radiohead Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1128+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)


	Add_Dir(
		name="[COLOR white][B]Coldplay Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1129+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)


	Add_Dir(
		name="[COLOR white][B]Steelheart Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1130+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)


	Add_Dir(
		name="[COLOR white][B]Killswitch Engage Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1131+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)


	Add_Dir(
		name="[COLOR white][B]Light The Torch Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1132+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hoobastank Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1133+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The White Stripes Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1134+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Creed Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1135+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Cult Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1136+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nickelback Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1137+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]3 Doors Down Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1138+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Incubus Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1139+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Linkin Park Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1140+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kings of Leon Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1141+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hinder Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1142+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Journey Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1143+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Reo Speedwagon Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1144+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bush Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1145+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Joan Jett N the Blackhearts[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1146+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bryan Adams Songs Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1147+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Greta Van Fleet Playlist[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1148+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_1rock.jpg", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)
	
#@route(mode='rock20')
def Rock20():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

#	Add_Dir(
#		name="[COLOR white][B]20 Great Rock Songs TEST I[/B][/COLOR]", url="plugin://plugin.video.youtube/play/?playlist_id=PLCADQnuKPGsoOKO9bSJnRMFLRsROHHQgB&play=1&order=default", folder=True,
#		icon=mediapath+"muzic_20s.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]20 Best Blues Rock[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1997+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_20s.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]20 Rock Ballads[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1998+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_20s.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]20 Great Rock Songs[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1999+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_20s.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]20 Hard Rock Songs[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1994+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_20s.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]20 Slow Rock Songs[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1996+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_20s.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]20 This Side Of Rock[/B][/COLOR]", url=pBASE+YOUTUBE_CHANNEL_ID_1995+"&play=1&order=default", folder=True,
		icon=mediapath+"muzic_20s.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)

#@route(mode='moremusicchannels')
def MoreMusicChannels():

	add_link_info('[B][COLORorange]=== Music ===[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Austin City Limits Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1976+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Paul McCartney Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1977+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]SBTV Music Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1926+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shinedown Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1470+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]David Gilmour Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1455+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Montreux Jazz Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1979+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Slipknot Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1928+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Green Day Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1929+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Greta Van Fleet[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1930+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Depeche Mode Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1931+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Stone Temple Pilots[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1932+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Skillet Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1933+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Pink Floyd Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1934+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The AC/DC Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1935+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Def Leppard Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1936+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Deep Purple Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1937+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music: U2 Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1938+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rival Sons Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1939+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Band Camino[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1940+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Dirty Honey Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1941+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Crobot Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1942+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Foreigner Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1466+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Weird Al Yankovic[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1944+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lynyrd Skynyrd Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1945+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lady Gaga Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1946+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rihanna Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1947+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Metallica Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1453+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Britney Spears Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1949+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cranberries Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1454+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Red Hot Chili Peppers[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1951+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Queen Official Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1450+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cheap Trick Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1449+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Linkin Park Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1953+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lenny Kravitz Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1955+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Kid Rock Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1957+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Foo Fighters Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1958+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Alice In Chains[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1959+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rolling Stones Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1960+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Vevo Playlists Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1961+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Katy Perry Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1485+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Cardi B Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1963+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Taylor Swift Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1475+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Snoop Dogg Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1965+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Led Zeppelin Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1966+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Eagles Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1967+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bob Dylan On Vevo[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1978+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rap Party Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1968+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Red Music Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1969+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Black Eyed Peas[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1970+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Van Halen Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1971+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Heart Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1458+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Beatles Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1973+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The REM Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1974+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Jimi Hendrix Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1975+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music Channel Mix[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1925+"/", folder=True,
		icon=mediapath+"muzic_more.png", fanart=fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'muzic.png', fanart)
	
#@route(mode='rap_channels')
def Rap_Channels():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]The Wham Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1491+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Taylor Swift Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1475+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ariana Grande Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1476+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bebe Rexha Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1477+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Maroon 5 Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1478+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Nipsey Hustle Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1479+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Cardi B Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1480+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lil Dicky Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1481+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Meghan Trainor Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1482+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Beyonce Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1483+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Rihanna Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1484+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Katy Perry Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1485+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Drake Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1486+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Lady Gaga Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1487+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Wiz Khalifa Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1488+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Fetty Wap Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1489+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]50 Cent Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1490+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Black Eyed Peas Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1492+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Yo Gotti Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1493+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Ashanti Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1494+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mariah Carey Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1495+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Destinys Child Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1496+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Alicia Keys Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1497+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Usher Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1498+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Ne-Yo Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1500+"/", folder=True,
		icon=mediapath+"muzic_rap.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)
	
#@route(mode='rock_channels')
def Rock_Channels():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]David Gilmour Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1455+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Grateful Dead Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1456+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Queen Official Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1450+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Linkin Park Channel[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1451+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Soundgarden Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1452+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Metallica Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1453+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Cranberries Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1454+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Aerosmith Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1457+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Band Heart Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1458+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AC-DC Official Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1459+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Pearl Jam Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1460+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Tom Petty Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1461+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Phil Collins Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1462+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ozzie Osbourne Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1463+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Motley Crue Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1464+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Kiss Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1465+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Foreigner Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1466+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Creed Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1467+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Bon Jovi Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1468+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Alter Bridge Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1469+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Shinedown Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1470+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Def Leppard Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1471+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Judas Priest Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1472+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Foo Fighters Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1473+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The U2 Channel[/B][/COLOR]", url=cBASE+YOUTUBE_CHANNEL_ID_1474+"/", folder=True,
		icon=mediapath+"muzic_rock.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)
	
#@route(mode='muzic_video')
def Muzic_Video():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Best Of George Michaels[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1413+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Time Most Viewed[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1414+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Country Music Videos[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1415+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Rock Videos[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1416+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Music Vault[/B][/COLOR]", url=uBASE+YOUTUBE_CHANNEL_ID_1417+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Music Videos[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1418+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Weird Al Yankovic[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1419+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Top 100 Hip-Hop Video[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1420+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]All Time Top Country[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1421+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Country Music Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1422+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Christian Music Video[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1423+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]60s Music Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1424+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]60s-70s Heavy Metal[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1425+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]70s Hits Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1426+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]70s Music Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1427+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]70s Punk Rock Videos[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1428+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]80s Music Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1430+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]80s-90s Heavy Metal[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1431+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]90s Music Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1432+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]90s Hip Hop N R&B[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1433+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]90s-00s Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1434+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]2000s Hits Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1435+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]2010s Heavy Metal[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1436+"/", folder=True,
		icon=mediapath+"muzic_music.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)
	
#@route(mode='concert')
def Concert():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]David Gilmore Live At Pompeii[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1024+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rock Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1001+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Metal - Melodic Rock Concert[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1003+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Heavy Metal Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1004+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Country Music Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1005+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hard Rock And Metal Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1006+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]720p HD Rock Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1007+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Rock Am Ring Concert[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1008+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Joe Cocker Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1009+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Moshcam Full Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1010+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Concerts: Kiss[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1012+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]HD Concert Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1013+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full Length Artist Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1014+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Oldies, Soul RnB, Funk[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1015+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classical Full Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1016+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Tokyo Jazz Festival[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1017+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Concerts: David Bowie[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1018+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Christian Music Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1019+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]RnB And Soul Music Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1020+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Complete Concerts: Blues[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1021+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Eminem Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1022+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Mix Genre Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1023+"/", folder=True,
		icon=mediapath+"muzic_concert.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)

#@route(mode='muzicdocs')
def Muzicdocs():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Music Movies And Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1325+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music And Bands Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1326+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1328+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]More Music Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1329+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Full Music Documentaries[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1330+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Music Documentary: Rock[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1331+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]Music Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1332+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More Music Docs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1333+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)		
		
	Add_Dir(
		name="[COLOR white][B]Jazz: History of Americas Music[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1334+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]BBC Music Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1335+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Punk Music Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1336+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Universe Documentary[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1337+"/", folder=True,
		icon=mediapath+"muzic_docs.png", fanart=fanart)
		
	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)

#@route(mode='songs')
def Songs():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]1080p Rock Songs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1029+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]AC-DC Songs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1030+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]HD Original Music Videos[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1031+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]U2 Songs HD[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1032+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Elvis Presley 68 Comeback[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1033+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]80s Glam, Rock, Hair Metal[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1034+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Songs: Pink Floyd Pulse[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1035+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Slow Rock, Anthem[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1036+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Vevo Best Rock 2019[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1037+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Top Tracks Classical Music[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1038+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Demi Lovato Top 50[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1039+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Country Music Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1040+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Female Folk Singers[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1041+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Guitar Heroes: The Soloist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1042+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Oldies Music Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1043+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Favorites Music Mix[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1044+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Who: Songs And Concerts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1047+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Midnight Special TV Collection[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1048+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Greatest New Wave Songs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1049+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Alice Cooper Greatest Hits[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1050+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hip Hop Songs 2019[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1051+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Most Viewed On Youtube[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1052+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Rap Songs 2019[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1053+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Country Top 40 Songs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1054+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Top 100 Hip Hop Videos[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1055+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Hottest Rap Video Playlist[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1056+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Clean RnB And Hip Hop Music[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1058+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Rock Live Performances[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1059+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Songs: Jazz Rock Fusion[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1060+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]New Gaither List 2018[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1061+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Greatest Hippie Songs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1062+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Best Country Music[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1063+"/", folder=True,
		icon=mediapath+"muzic_singles.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)

#@route(mode='muzic_musical')
def Muzic_musical():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]Musical Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1360+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]More Musical Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1361+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Comedy Musicals And Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1362+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Movies: Musicals[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1363+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Classic Musicals And Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1364+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Moms Musical Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1365+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Devo Classic Musicals And Shorts[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1366+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Musical: Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1367+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)
		
	Add_Dir(
		name="[COLOR white][B]Country Music Movies[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1368+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Musical Movies And Plays[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1369+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Short Musical Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1370+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Full Musicals - Bootlegs[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1371+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Musical Films[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1372+"/", folder=True,
		icon=mediapath+"muzic_musical.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)

#@route(mode='muzictv')
def MuzicTV():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice UK Best Battles[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1388+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Australia S2[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1389+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Ready, Steady, Go: 60s British[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1390+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Music TV Shows: The Voice[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1391+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TV: The Midnight Special[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1392+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Beat Club: German[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1393+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]Solid Gold Tv Show[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1394+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]TV: The Voice UK[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1395+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice UK Blind Auditions[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1396+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Kids: 2015 Blind Auditions[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1397+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Season 2[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1398+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice Season 3[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1399+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	Add_Dir(
		name="[COLOR white][B]The Voice UK Series 5[/B][/COLOR]", url=BASE+YOUTUBE_CHANNEL_ID_1400+"/", folder=True,
		icon=mediapath+"muzic_tvshow.png", fanart=fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)

#xbmcplugin.endOfDirectory(plugin_handle)
