# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from resources.lib.modules.muzicStreams import *
from resources.lib.modules.karaokeCH import *
from resources.lib.modules.muzicNow import *
from resources.lib.modules.muzicscraper import *
from resources.lib.modules.showVID import *
from resources.lib.modules.muzic import *
from resources.lib.modules.common import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
artAddon     = 'script.j1.artwork'

selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.muzic')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'
media = 'special://home/addons/script.j1.artwork/lib/resources/images/genres/'

BASE  = "plugin://plugin.video.youtube/playlist/"
cBASE = "plugin://plugin.video.youtube/channel/"
uBASE = "plugin://plugin.video.youtube/user/"
pBASE = "plugin://plugin.video.youtube/play/?playlist_id="

#=========================================================================================================================================

def Main():

	add_link_info('[B][COLORorange]==== Muzic ====[/COLOR][/B]', mediapath+'muzic.png', fanart)

	addDirMain('[COLOR white][B]Music: Just The Classics[/B][/COLOR]',BASE,325,mediapath+'muzic_classic.png',fanart)
	addDirMain('[COLOR white][B]Music: Just The 2000s[/B][/COLOR]',BASE,326,mediapath+'muzic_2000s.png',fanart)
	addDirMain('[COLOR white][B]Music: One Click Rock Groups[/B][/COLOR]',BASE,323,mediapath+'muzic_1rock.jpg',fanart)
	addDirMain('[COLOR white][B]Music: One Click 20s Of Rock[/B][/COLOR]',BASE,322,mediapath+'muzic_20s.png',fanart)
	addDirMain('[COLOR white][B]Music: One Click The Voice[/B][/COLOR]',BASE,324,mediapath+'muzic_voice.png',fanart)
	addDirMain('[COLOR white][B]Music: 1 Click Documentary[/B][/COLOR]',BASE,409,mediapath+'muzic_doc.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Music: Songs, Anthems, Docs[/B][/COLOR]',BASE,403,mediapath+'muzic_anthem.png',fanart)
	addDirMain('[COLOR white][B]Music: Genre Listing[/B][/COLOR]',BASE,404,mediapath+'muzic_genre.png',fanart)
	addDirMain('[COLOR white][B]Music: Streams[/B][/COLOR]',BASE,405,mediapath+'muzic_streams.png',fanart)
	addDirMain('[COLOR white][B]Music: Concerts[/B][/COLOR]',BASE,406,mediapath+'muzic_concert.png',fanart)
	addDirMain('[COLOR white][B]Music: Karaoke[/B][/COLOR]',BASE,408,mediapath+'muzic_karaoke.png',fanart)
	addDirMain('[COLOR white][B]Rock Channels[/B][/COLOR]',BASE,37,mediapath+'muzic_rock.png',fanart)
	addDirMain('[COLOR white][B]Rap, Pop, R&B[/B][/COLOR]',BASE,38,mediapath+'muzic_rap.png',fanart)
	addDirMain('[COLOR white][B]Music Videos[/B][/COLOR]',BASE,39,mediapath+'muzic_music.png',fanart)
	addDirMain('[COLOR white][B]More Documentaries[/B][/COLOR]',BASE,32,mediapath+'muzic_docs.png',fanart)
	addDirMain('[COLOR white][B]More Music Channels[/B][/COLOR]',BASE,321,mediapath+'muzic_more.png',fanart)
	addDirMain('[COLOR white][B]Singles, Songs, Hits[/B][/COLOR]',BASE,33,mediapath+'muzic_singles.png',fanart)
	addDirMain('[COLOR white][B]Musicals And Plays[/B][/COLOR]',BASE,35,mediapath+'muzic_musical.png',fanart)
	addDirMain('[COLOR white][B]TV Show Song Playlist[/B][/COLOR]',BASE,36,mediapath+'muzic_tvshow.png',fanart)
	addDirMain('[COLOR white][B]Now Thats Music[/B][/COLOR]',BASE,407,mediapath+'muzic_music.png',fanart)
	addDirMain('[COLOR white][B]Concert Playlists[/B][/COLOR]',BASE,31,mediapath+'muzic_concert.png',fanart)

	add_link_info('[B][COLORlime] [/COLOR][/B]', mediapath+'muzic.png', fanart)

def genreList():

	add_link_info('[B][COLORorange]== Choose Genre ==[/COLOR][/B]', icon, fanart)
	
	addDirMain('[COLOR white][B]All Music[/B][/COLOR]',BASE,403,media+'All-muzic.png', fanart)
	addDirMain('[COLOR white][B]Alternative Music[/B][/COLOR]',BASE,410,media+'Alternative.png', fanart)
	addDirMain('[COLOR white][B]Anthems Music[/B][/COLOR]',BASE,411,media+'Anthem.png', fanart)
	addDirMain('[COLOR white][B]Blues Music[/B][/COLOR]',BASE,412,media+'Blues.png', fanart)
	addDirMain('[COLOR white][B]Country Music[/B][/COLOR]',BASE,413,media+'Country.png', fanart)
	addDirMain('[COLOR white][B]Music Docs[/B][/COLOR]',BASE,414,media+'Docs.png', fanart)
	addDirMain('[COLOR white][B]Hip Hop Music[/B][/COLOR]',BASE,415,media+'Hip Hop.png', fanart)
	addDirMain('[COLOR white][B]Jazz Music[/B][/COLOR]',BASE,416,media+'Jazz.png', fanart)
	addDirMain('[COLOR white][B]Metal Music[/B][/COLOR]',BASE,417,media+'Metal.png', fanart)
	addDirMain('[COLOR white][B]Movie Music[/B][/COLOR]',BASE,418,media+'Movie.png', fanart)
	addDirMain('[COLOR white][B]Pop Music[/B][/COLOR]',BASE,419,media+'Pop.png', fanart)
	addDirMain('[COLOR white][B]Punk Music[/B][/COLOR]',BASE,420,media+'Punk.png', fanart)
	addDirMain('[COLOR white][B]RnB Music[/B][/COLOR]',BASE,421,media+'RnB.png', fanart)
	addDirMain('[COLOR white][B]Rock Music[/B][/COLOR]',BASE,422,media+'Rock.png', fanart)
	addDirMain('[COLOR white][B]Rap Music[/B][/COLOR]',BASE,423,media+'Rap.png', fanart)
	addDirMain('[COLOR white][B]Soul[/B][/COLOR]',BASE,424,media+'Soul.png', fanart)
	addDirMain('[COLOR white][B]TV Music[/B][/COLOR]',BASE,425,media+'TV.png', fanart)

	add_link_info('[B][COLORorange] [/COLOR][/B]', icon, fanart)

#==========================================================================================================
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
		
params=get_params()
url=None
name=None
mode = None
iconimage=None
mode=None
description=None

#===================== Python 2 ======================

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#===================== Python 3 ======================

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.parse.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

#======= MUZIC =======
		
if mode == 31:
	Concert()

elif mode == 32:
	Muzicdocs()

elif mode == 33:
	Songs()

elif mode == 34:
	Kids_music()
	
elif mode == 35:
	Muzic_musical()
	
elif mode == 36:
	MuzicTV()
	
elif mode == 37:
	Rock_Channels()
	
elif mode == 38:
	Rap_Channels()
	
elif mode == 39:
	Muzic_Video()
	
elif mode == 321:
	MoreMusicChannels()
	
elif mode == 322:
	Rock20()
	
elif mode == 323:
	OneClickRock()
	
elif mode == 324:
	theVoice()
	
elif mode == 325:
	justClassics()
	
elif mode == 326:
	just2000s()

#=========================================

#elif mode == 403:
#    Singles.singles_list()
	
#elif mode == 404:
#    Singles.genres_list()
	
#elif mode == 406:
    #Channels.genres_list()

#=========================================
		
elif mode == 402:
	from resources.lib.modules.showsPL import *

elif mode == 403:
    Listing.Genres("All","Genres")
	
elif mode == 404:
    genreList()

elif mode == 405:
    streamListing.Genres("All")
	
elif mode == 406:
    Listing.Genres("All","Concerts")
	
elif mode == 407:
    nowListing.Genres("All")
	
elif mode == 408:
    karaokeCH.Genres("All")
	
elif mode == 409:
    Listing.Genres("All","Docs")

#=========================================

elif mode == 410:
    Listing.Genres("Alternative","Genres")

elif mode == 411:
    Listing.Genres("Anthem","Genres")

elif mode == 412:
    Listing.Genres("Blues","Genres")

elif mode == 413:
    Listing.Genres("Country","Genres")

elif mode == 414:
    Listing.Genres("Docs","Genres")

elif mode == 415:
    Listing.Genres("HipHop","Genres")

elif mode == 416:
    Listing.Genres("Jazz","Genres")

elif mode == 417:
    Listing.Genres("Metal","Genres")

elif mode == 418:
    Listing.Genres("Movie","Genres")

elif mode == 419:
    Listing.Genres("Pop","Genres")

elif mode == 420:
    Listing.Genres("Punk","Genres")

elif mode == 421:
    Listing.Genres("RnB","Genres")

elif mode == 422:
    Listing.Genres("Rock","Genres")

elif mode == 423:
    Listing.Genres("Rap","Genres")

elif mode == 424:
    Listing.Genres("Soul","Genres")

elif mode == 425:
    Listing.Genres("TV")

#=========================================

elif mode == 801:
		
	#errorMsg="%s" % (url)
	#xbmcgui.Dialog().ok("url", errorMsg)

	Common.getVID(url)

#=========================================

#elif mode in muziclib.Common.get_singles_genres():
#    Singles.genre_list(mode)

elif mode is None:
	Main()
	
else:		

    #Channels.get_channel(mode)
    #Singles.get_singles(mode)

    try: mode in Singles.get_singles(mode)
    except:
        pass	

    try: mode in Channels.get_channel(mode)
    except:
        pass	
		
xbmcplugin.endOfDirectory(plugin_handle)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
