import logging

import routing
import xbmcaddon
from resources.lib import kodilogging, kodiutils, moods
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl

GENRE_ALL = 0
GENRE_JAZZ = 1
GENRE_BLUES = 2
GENRE_WORLD = 3
GENRE_BLACK = 4
GENRE_OTHER = 5

ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))
kodilogging.config()
plugin = routing.Plugin()


@plugin.route('/')
def index():
    logger.debug('index()')
    li = ListItem(kodiutils.get_string(30004))
    logger.debug(kodiutils.get_string(30004))
    addDirectoryItem(
        handle=plugin.handle,
        url=plugin.url_for(list_concerts, genre=GENRE_ALL),
        listitem=li,
        isFolder=True)
    li = ListItem(kodiutils.get_string(30005))
    addDirectoryItem(
        handle=plugin.handle,
        url=plugin.url_for(list_concerts, genre=GENRE_JAZZ),
        listitem=li,
        isFolder=True)
    li = ListItem(kodiutils.get_string(30006))
    addDirectoryItem(
        handle=plugin.handle,
        url=plugin.url_for(list_concerts, genre=GENRE_BLUES),
        listitem=li,
        isFolder=True)
    li = ListItem(kodiutils.get_string(30007))
    addDirectoryItem(
        handle=plugin.handle,
        url=plugin.url_for(list_concerts, genre=GENRE_WORLD),
        listitem=li,
        isFolder=True)
    li = ListItem(kodiutils.get_string(30008))
    addDirectoryItem(
        handle=plugin.handle,
        url=plugin.url_for(list_concerts, genre=GENRE_BLACK),
        listitem=li,
        isFolder=True)
    li = ListItem(kodiutils.get_string(30009))
    addDirectoryItem(
        handle=plugin.handle,
        url=plugin.url_for(list_concerts, genre=GENRE_OTHER),
        listitem=li,
        isFolder=True)
    endOfDirectory(plugin.handle)


@plugin.route('/concerts/<genre>')
def list_concerts(genre):
    logger.debug('concerts({})'.format(genre))
    for concert in moods.get_concerts(genre):
        li = ListItem(concert['title'])
        li.setArt({'thumb': concert['thumb']})
        li.setInfo('video', {'title': concert['title'],
                             'plot': concert['details'],
                             'genre': concert['genre'],
                             'aired': concert['date'],
                             'mediatype': 'video'})
        li.setLabel2(concert['genre'])
        li.setProperty('IsPlayable', 'true')
        addDirectoryItem(
            handle=plugin.handle,
            url=plugin.url_for(
                play_concert,
                page=concert['page'],
                index=concert['index'],
                title=concert['title'],
                genre=concert['genre'],
                thumb=concert['thumb'],
                aired=concert['date']),
            listitem=li,
            isFolder=False)
    endOfDirectory(plugin.handle)


@plugin.route('/concert/play')
def play_concert():
    page = plugin.args["page"][0]
    index = plugin.args["index"][0]
    title = plugin.args["title"][0]
    genre = plugin.args["genre"][0]
    thumb = plugin.args["thumb"][0]
    aired = plugin.args["aired"][0]
    logger.debug('play_concert({})'.format(page))
    concert = moods.get_concert(page, index)
    li = ListItem(title)
    li.setArt({'thumb': thumb})
    li.setInfo('video', {'title': title,
                         'plot': concert['details'],
                         'genre': genre,
                         'aired': aired,
                         'mediatype': 'video'})
    li.setLabel2(genre)
    li.setProperty('IsPlayable', 'true')
    li.setPath(concert['hls'])
    setResolvedUrl(handle=plugin.handle, succeeded=True, listitem=li)


def run():
    logger.debug('run()')
    plugin.run()
