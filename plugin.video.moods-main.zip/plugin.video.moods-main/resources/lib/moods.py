import logging
import re

import requests

MOODS_DOMAIN = 'https://www.moods.digital'
MOODS_VOD_URL = MOODS_DOMAIN + "/en/vod/chronological/?m="

REGEX_CONCERTS = (
    r"class=\"(?:event.+?href=\"(?P<page>[^\"]+?)\"|left child).+?3x,\ "
    r"(?P<thumb>/cache.+?)\ 4x\".+?class=\"day\">(?P<day>\d+).+?day_name\">"
    r"(?P<month>\w+).+?month_name\">(?P<year>\d+).+?h2>(?P<title>.+?)"
    r"<\/h2.+?class=\"content\">(?P<details>.*?)</div.+?music_style\">"
    r"(?P<genre>.+?)</span")

REGEX_HASH = (
    r"video-player\" href=\"(?P<url>[^\"]+).+?hash=\"(?P<hash>\w+)\".+?"
    r"class=\"performers\">(?P<performers>.+?)</div.+?class=\"content\">"
    r"(?P<content>.+?)</div"
)
REGEX_SCRIPT = r"getScript\('(?P<script>[^']+)"
REGEX_PLAYLIST = r"playlist\": \"(?P<playlist>[^\"]+)"
REGEX_HLS = r"file\":\"(?P<hls>[^\"]+m3u8[^\"]+)"

MONTHS = {
    'Jan': '01',
    'Feb': '02',
    'Mar': '03',
    'Apr': '04',
    'May': '05',
    'Jun': '06',
    'Jul': '07',
    'Aug': '08',
    'Sep': '09',
    'Oct': '10',
    'Nov': '11',
    'Dec': '12',
}
USER_AGENT_HEADER = {'User-Agent': ('Mozilla/5.0 (X11; Linux x86_64; rv:96.0) '
                                    'Gecko/20100101 Firefox/96.0')}
XHR_HEADER = {'X-Requested-With': 'XMLHttpRequest'}

logger = logging.getLogger(__name__)


def get_concerts(genre=0):
    logger.debug('get_concerts({})'.format(genre))
    page = requests.get(MOODS_VOD_URL + str(genre), headers=USER_AGENT_HEADER)

    matches = re.finditer(REGEX_CONCERTS, page.text, re.DOTALL)
    last_page = ''
    index = 0

    for _, match in enumerate(matches, start=1):
        logger.debug("found: {}".format(match.group('title')))
        if match.group('page') is not None:
            page = MOODS_DOMAIN + match.group('page')
            index = 0
        else:
            page = last_page
            index += 1
        last_page = page
        yield {
            'title': match.group('title'),
            'page': page,
            'index': index,
            'thumb': MOODS_DOMAIN + match.group('thumb'),
            'details': match.group('details'),
            'genre': match.group('genre'),
            'date': "{}-{}-{}".format(match.group('year'),
                                      MONTHS[match.group('month')],
                                      match.group('day')),
        }


def get_concert(url, index):
    logger.debug('get_concert({}, {})'.format(url, index))
    headers = {**USER_AGENT_HEADER, **XHR_HEADER}
    page = requests.get(url, headers=headers)
    event = page.json()['event']
    logger.debug(event)
    concert_match = None

    matches = re.finditer(REGEX_HASH, event, re.DOTALL)
    for i, match in enumerate(matches, start=1):
        if i == int(index) + 1:
            concert_match = match
            break

    url = MOODS_DOMAIN + concert_match['url']
    hash = concert_match.group('hash')
    details = concert_match.group('performers') + match.group('content')
    details = details.replace('<br />', '[CR]')
    details = details.replace('<p>', '[CR]')
    details = details.replace('</p>', '[CR][CR]')
    details = details.replace('<b>', '[B]')
    details = details.replace('</b>', '[/B]')
    details = re.sub(r'<h\d>', '[B]', details)
    details = re.sub(r'</h\d>', '[/B]', details)
    details = re.sub(r'<[^>]+>', '', details)
    logger.debug('hash: {}'.format(hash))

    page = requests.post(
        url,
        headers=headers,
        data={
            'custom_action': 'get_video_player',
            'hash': hash,
            'type': 'vod',
            'source': 'stereo'})
    match = re.search(REGEX_SCRIPT, page.text)
    script = match.group('script').replace('\\/', '/')
    logger.debug('script: {}'.format(script))

    page = requests.get(script, headers=USER_AGENT_HEADER)
    logger.debug(page.text)
    match = re.search(REGEX_PLAYLIST, page.text)
    playlist = 'https:' + match.group('playlist')
    logger.debug('playlist: {}'.format(playlist))

    page = requests.get(playlist, headers=USER_AGENT_HEADER)
    logger.debug(page.text)
    match = re.search(REGEX_HLS, page.text)
    hls = match.group('hls')
    return {
        'details': details,
        'hls': hls,
    }
