import logging

import xbmcaddon

# read settings
ADDON = xbmcaddon.Addon()

logger = logging.getLogger(__name__)


def get_setting(setting):
    return ADDON.getSetting(setting).strip()


def get_setting_as_bool(setting):
    return get_setting(setting).lower() == "true"


def get_string(string_id):
    logger.debug('get_string(%s)', string_id)
    logger.debug(ADDON.getLocalizedString(string_id))
    return str(ADDON.getLocalizedString(string_id))
